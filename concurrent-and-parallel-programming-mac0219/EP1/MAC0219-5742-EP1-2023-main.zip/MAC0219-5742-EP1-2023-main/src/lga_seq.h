#ifndef _LGA_SEQ_H
#define _LGA_SEQ_H

void simulate_seq(byte *grid_1, byte *grid_2, int grid_size);

#endif
